<template>
  <div class="layout-copy">
    2011-2016 &copy; TalkingData
  </div>
</template>

<style scoped>
  .layout-copy {
    text-align: center;
    padding: 10px 0 20px;
    color: #9ea7b4;
  }
</style>