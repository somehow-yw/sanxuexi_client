<template>
  <div class="layout-assistant">
      <Menu-item name="1">二级3</Menu-item>
      <Menu-item name="2">二级3</Menu-item>
      <Menu-item name="3">二级3</Menu-item>
  </div>
</template>